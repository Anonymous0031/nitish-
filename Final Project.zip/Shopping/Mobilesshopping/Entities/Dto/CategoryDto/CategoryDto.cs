﻿using OnlineShopping.Entities.Dto.ProductDto;

namespace OnlineShopping.Entities.Dto.CategoryDto
{
    public class CategoryDto
    {
        public int Id { get; set; }
        public string CategoryName { get; set; }
        public List<ResponseProductDto> Products { get; set; }
    }
}
