﻿using Microsoft.AspNetCore.Mvc;
using OnlineShopping.Entities.Dto.CategoryDto;
using OnlineShopping.Entities.Dto.OrdersDto;
using OnlineShopping.Entities.Dto.ProductDto;
using OnlineShopping.Entities.Dto.UserDto;
using OnlineShopping.Entities.Models;

namespace OnlineShopping.Repository.Interfaces
{
    public interface IUserRepository
    {

        Task<RegisterUserDto> Register(RegisterUserDto registeruserdto);

        Task<string> Login(LoginUserDto loginUserDto);

        Task<IEnumerable<ResponseProductDto>> GetAllProducts();
        Task<IEnumerable<ResponseProductDto>> GetProductsByCategory(int categoryId);
        Task<List<CategoryDto>> GetCategories();
        Task<IEnumerable<ResponseProductDto>> SearchByBrand(string brandName);
        Task<RegisterUserDto> UpdateUser(int Id, RegisterUserDto user);
        Task<string> CheckOut(string userEmail);
        Task<IEnumerable<OrderItemDto>> GetOrdersByUserId(string userEmail);


    }
}
