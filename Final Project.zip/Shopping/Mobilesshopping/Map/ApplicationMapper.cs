﻿using AutoMapper;
using OnlineShopping.Entities.Dto.AdminDto;
using OnlineShopping.Entities.Dto.CartItemDto;
using OnlineShopping.Entities.Dto.CategoryDto;
using OnlineShopping.Entities.Dto.ProductDto;
using OnlineShopping.Entities.Dto.UserDto;
using OnlineShopping.Entities.Models;

namespace OnlineShopping.Map
{
    public class ApplicationMapper : Profile
    {
        public ApplicationMapper()
        {
            CreateMap<User, RegisterUserDto>().ReverseMap();
            CreateMap<User, LoginUserDto>().ReverseMap();
            CreateMap<Admin, LoginAdminDto>().ReverseMap();
            CreateMap<Admin, RegisterAdminDto>().ReverseMap();
            CreateMap<Product, RequestProductDto>().ReverseMap();
            CreateMap<Product, ResponseProductDto>().ReverseMap();
            CreateMap<Category, CategoryDto>().ReverseMap();
            CreateMap<Category, AddCategoryDto>().ReverseMap();
            CreateMap<CartItem, CartItemDto>().ReverseMap();

        }


    }
}
