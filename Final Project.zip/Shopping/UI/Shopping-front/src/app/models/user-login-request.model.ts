export interface UserLoginRequest{
    email:string;
    password:string;
}